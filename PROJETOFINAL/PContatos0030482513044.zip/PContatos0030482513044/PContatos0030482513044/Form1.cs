﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace PContatos0030482513044
{
    public partial class FrmPrincipal : Form
    {
        public static SqlConnection conexao;
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=HGZIN;Initial Catalog=BD;Integrated Security=True");
                conexao.Open();
                // Operações com o banco de dados
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros Erros =/" + ex.Message);
            }

        }

        private void cadastrarContatosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmContato>().Count() > 0)
            {
                Application.OpenForms["FrmContato"].BringToFront();
            }
            else
            {
                FrmContato FRMC = new FrmContato();
                FRMC.MdiParent = this;
                FRMC.WindowState = FormWindowState.Maximized;
                FRMC.Show();

            }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            if (Application.OpenForms.OfType<sobre>().Count() > 0) 
            { 
                Application.OpenForms["frmExercicio2"].BringToFront();
                
            } 
            
            else 
            { 
                sobre frm_2 = new sobre(); frm_2.MdiParent = this; frm_2.WindowState = FormWindowState.Maximized; frm_2.Show(); 
            }

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
