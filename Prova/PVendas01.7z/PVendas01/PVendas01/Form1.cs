﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] Vendas = new double[3, 4];
            string Auxiliar = "";
            double VendasGeral = 0;
            double VendasMes = 0;
            double VendasSemana = 0;
            string Saída = "";

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                   Auxiliar = Interaction.InputBox($"Digite os lucros da {j + 1}° semana do mês {i + 1}", "Entrada de dados");

                    if (!Double.TryParse(Auxiliar, out Vendas[i, j]) || Vendas[i, j] <= 0)
                    {
                        MessageBox.Show("Dados inválidos");
                    }

                    else
                    {
                        VendasGeral += Vendas[i, j];
                    }

                    if(j<5)
                    {
                        VendasSemana += Vendas[i, j];
                        LtbxVendas.Items.Add($"Vendas da semana {j+1} do mês {i+1}: {VendasSemana}");
                        VendasMes += VendasSemana;
                        VendasSemana = 0;
                    }
                    
                    if(i<4)
                    {
                        LtbxVendas.Items.Add($"Vendas do mês {i+1}: {VendasMes}");
                    }
                }
            }

            LtbxVendas.Items.Add($"Vendas gerais: {VendasGeral}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            LtbxVendas.Items.Clear();
        }
    }
}
