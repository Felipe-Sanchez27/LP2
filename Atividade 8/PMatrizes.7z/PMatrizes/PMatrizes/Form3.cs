﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Exercicio5 : Form
    {
        public Exercicio5()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int N = 5;
            int Questoes = 10;

            char[] gabarito = { 'A', 'C', 'B', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };
            char[,] respostas = new char[N, Questoes];
            int[] acertos = new int[N];

            for (int i = 0; i < N; i++)
            {
                MessageBox.Show($"Aluno {i + 1}", "Respostas do Aluno:");

                for (int j = 0; j < Questoes; j++)
                {
                    char resposta;
                    string entrada;

                    do
                    {
                        entrada = Interaction.InputBox(
                            $"Digite a resposta da questão {j + 1} (A, B, C, D ou E):", $"Aluno {i + 1}").Trim().ToUpper();

                        if (entrada.Length != 1 || !"ABCDE".Contains(entrada))
                        {
                            MessageBox.Show("Resposta inválida! Digite apenas A, B, C, D ou E.", "Erro");
                            entrada = "";
                        }

                    } while (entrada == "");

                    resposta = entrada[0];
                    respostas[i, j] = resposta;

                    if (resposta == gabarito[j])
                    {
                        acertos[i]++;
                    }
                }
            }
            lstbxGabarito.Items.Clear();
            for (int i = 0; i < N; i++)
            {
                lstbxGabarito.Items.Add($"Aluno {i + 1}: {acertos[i]} acertos de {Questoes}");
            }
        }
    }
}
