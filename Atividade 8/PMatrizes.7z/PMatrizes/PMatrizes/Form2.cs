﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Exercício4 : Form
    {
        public Exercício4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] Nomes = new string[10];
            int[] ComprimentoNome = new int[10];
            string auxiliar = "";

            for (int i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o nome completo da pessoa {i + 1}:", "Entrada de dados");
                auxiliar.Trim();

                if (string.IsNullOrWhiteSpace(auxiliar))
                {
                    MessageBox.Show("O nome não deve ser espaços vazios ou apenas espaços", "Atenção");
                }

                while (string.IsNullOrWhiteSpace(auxiliar)) ;
                Nomes[i] = auxiliar;
                ComprimentoNome[i] = auxiliar.Replace(" ", "").Length;

                lstbxNomes.Items.Add($"O nome {Nomes[i]} tem {ComprimentoNome[i]} caracteres");
            }
        }
    }
}
