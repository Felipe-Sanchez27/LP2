﻿namespace Pmetodos2._0
{
    partial class FrmExercício4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnNumberCounter = new System.Windows.Forms.Button();
            this.btnBlankSpace = new System.Windows.Forms.Button();
            this.btnLetterCounter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(177, 24);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(405, 203);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnNumberCounter
            // 
            this.btnNumberCounter.Location = new System.Drawing.Point(108, 252);
            this.btnNumberCounter.Name = "btnNumberCounter";
            this.btnNumberCounter.Size = new System.Drawing.Size(105, 53);
            this.btnNumberCounter.TabIndex = 1;
            this.btnNumberCounter.Text = "Contar Números";
            this.btnNumberCounter.UseVisualStyleBackColor = true;
            this.btnNumberCounter.Click += new System.EventHandler(this.btnNumberCounter_Click);
            // 
            // btnBlankSpace
            // 
            this.btnBlankSpace.Location = new System.Drawing.Point(325, 252);
            this.btnBlankSpace.Name = "btnBlankSpace";
            this.btnBlankSpace.Size = new System.Drawing.Size(106, 53);
            this.btnBlankSpace.TabIndex = 2;
            this.btnBlankSpace.Text = "Localiza Espaço";
            this.btnBlankSpace.UseVisualStyleBackColor = true;
            this.btnBlankSpace.Click += new System.EventHandler(this.btnBlankSpace_Click);
            // 
            // btnLetterCounter
            // 
            this.btnLetterCounter.Location = new System.Drawing.Point(537, 252);
            this.btnLetterCounter.Name = "btnLetterCounter";
            this.btnLetterCounter.Size = new System.Drawing.Size(108, 53);
            this.btnLetterCounter.TabIndex = 3;
            this.btnLetterCounter.Text = "Contar Letras";
            this.btnLetterCounter.UseVisualStyleBackColor = true;
            this.btnLetterCounter.Click += new System.EventHandler(this.btnLetterCounter_Click);
            // 
            // FrmExercício4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLetterCounter);
            this.Controls.Add(this.btnBlankSpace);
            this.Controls.Add(this.btnNumberCounter);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "FrmExercício4";
            this.Text = "FrmExercício4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnNumberCounter;
        private System.Windows.Forms.Button btnBlankSpace;
        private System.Windows.Forms.Button btnLetterCounter;
    }
}