﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos2._0
{
    public partial class FrmExercício4 : Form
    {
        public FrmExercício4()
        {
            InitializeComponent();
        }

        private void btnNumberCounter_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contaNum = 0;
            
            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[contador]))
                {
                    contaNum++;
                }

                contador++; //contaador +=1;
            }

            MessageBox.Show($"O texto tem {contaNum} números");

        }

        private void btnBlankSpace_Click(object sender, EventArgs e)
        {
            for (int i=0;i<rchtxtFrase.Text.Length;i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    MessageBox.Show($"A posição do primeiro caracter em branco é {i + 1}");
                    break;
                }

                else
                {
                    MessageBox.Show($"O texto não contém espaços em branco");
                }
            }
        }

        private void btnLetterCounter_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;
            foreach (char  c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetra++;
                }
            }

            MessageBox.Show($"O texto tem {contaLetra} letras");
        }
    }
}
