﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;
using System.Diagnostics.Eventing.Reader;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}° número", "Entrada de dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                MessageBox.Show("Valor inválido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            auxiliar = string.Join("\n", vetor);
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais" };
            lista.Remove("Otávio");
            string auxiliar = "";
            foreach (string nome in lista)
                auxiliar += nome + "\n";

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            Double[,] Notas = new double[20, 3];
            string auxiliar = "";
            string saída = "";
            double média = 0.0;
            for (int i = 0;i<20;i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1})", "Entrada de dados");

                    if (!(Double.TryParse(auxiliar, out Notas[i, j]) || Notas[i, j] < 0 || Notas[i, j] > 10))
                    {

                        MessageBox.Show("Dados inválidos");
                    }

                    else
                    {
                        média += Notas[i, j];
                    }

                    saída += ($"\nAluno {i+1}. Média: {média / 3} \n");
                    média = 0;
                }
                MessageBox.Show(saída);            
            }
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exercício4>().Count() > 0)
            {
                Application.OpenForms["Exercício4"].BringToFront();
            }
            else
            {
                Exercício4 frm_2 = new Exercício4();
                frm_2.Show();
            }
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exercicio5>().Count() > 0)
            {
                Application.OpenForms["Exercicio5"].BringToFront();
            }
            else
            {
                Exercicio5 frm_2 = new Exercicio5();
                frm_2.Show();
            }
        }
    }
}
