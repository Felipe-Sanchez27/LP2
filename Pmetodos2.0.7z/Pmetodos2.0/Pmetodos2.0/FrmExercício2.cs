﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos2._0
{
    public partial class FrmExercício2 : Form
    {
        public FrmExercício2()
        {
            InitializeComponent();
        }

        private void btninserir2_Click(object sender, EventArgs e)
        {
            int meio = txtpalavra1.Text.Length / 2;

            txtpalavra2.Text = txtpalavra1.Text.Insert(meio, "**");
        }

        private void btninserir_Click(object sender, EventArgs e)
        {
            int meio = txtpalavra2.SelectionLength / 2;

            txtpalavra2.Text=txtpalavra2.Text.Substring(0,meio)+txtpalavra1.Text+txtpalavra2
            .Text.Substring(meio,txtpalavra2.Text.Length-meio);
        }

        private void btnverificar_Click(object sender, EventArgs e)
        {

        }
    }
}
