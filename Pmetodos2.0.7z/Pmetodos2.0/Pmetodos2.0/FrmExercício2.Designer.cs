﻿namespace Pmetodos2._0
{
    partial class FrmExercício2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.btnverificar = new System.Windows.Forms.Button();
            this.btninserir = new System.Windows.Forms.Button();
            this.btninserir2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(223, 60);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(328, 26);
            this.txtpalavra1.TabIndex = 0;
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(223, 123);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(328, 26);
            this.txtpalavra2.TabIndex = 1;
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(128, 60);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(74, 20);
            this.lblpalavra1.TabIndex = 2;
            this.lblpalavra1.Text = "Palavra 1";
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(128, 123);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(74, 20);
            this.lblpalavra2.TabIndex = 3;
            this.lblpalavra2.Text = "Palavra 2";
            // 
            // btnverificar
            // 
            this.btnverificar.Location = new System.Drawing.Point(103, 200);
            this.btnverificar.Name = "btnverificar";
            this.btnverificar.Size = new System.Drawing.Size(83, 62);
            this.btnverificar.TabIndex = 4;
            this.btnverificar.Text = "Verificar Iguais";
            this.btnverificar.UseVisualStyleBackColor = true;
            this.btnverificar.Click += new System.EventHandler(this.btnverificar_Click);
            // 
            // btninserir
            // 
            this.btninserir.Location = new System.Drawing.Point(223, 200);
            this.btninserir.Name = "btninserir";
            this.btninserir.Size = new System.Drawing.Size(151, 62);
            this.btninserir.TabIndex = 5;
            this.btninserir.Text = "Inserir 1* no meio da 2 palavra";
            this.btninserir.UseVisualStyleBackColor = true;
            this.btninserir.Click += new System.EventHandler(this.btninserir_Click);
            // 
            // btninserir2
            // 
            this.btninserir2.Location = new System.Drawing.Point(408, 200);
            this.btninserir2.Name = "btninserir2";
            this.btninserir2.Size = new System.Drawing.Size(143, 66);
            this.btninserir2.TabIndex = 6;
            this.btninserir2.Text = "Inserir 2* no meio da 1 palavra";
            this.btninserir2.UseVisualStyleBackColor = true;
            this.btninserir2.Click += new System.EventHandler(this.btninserir2_Click);
            // 
            // FrmExercício2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btninserir2);
            this.Controls.Add(this.btninserir);
            this.Controls.Add(this.btnverificar);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Name = "FrmExercício2";
            this.Text = "FrmExercício2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.Button btnverificar;
        private System.Windows.Forms.Button btninserir;
        private System.Windows.Forms.Button btninserir2;
    }
}