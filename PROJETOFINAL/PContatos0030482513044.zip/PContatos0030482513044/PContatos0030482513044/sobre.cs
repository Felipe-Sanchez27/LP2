﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContatos0030482513044
{
    public partial class sobre : Form
    {
        public sobre()
        {
            InitializeComponent();
        }

        private void btnsobre_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Este projeto foi feito pelos alunos do segundo smestre de Análise e Desenvoldimento de Sistemas da Fatec Sorocaba: Higor Souza Nascimento, Guilherme de Souza Oliveira, Felipe Sanchez Maldonado");
        }

        private void sobre_Load(object sender, EventArgs e)
        {

        }

        private void btnvoltarSB_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
