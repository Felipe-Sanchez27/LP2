using System.Diagnostics.Eventing.Reader;

namespace PVolume
{
    public partial class Form1 : Form
    {
        Double raio, altura, volume;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtRaio_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio)
                || (raio <= 0)) //a barra vertical significa OU
            {
                MessageBox.Show("Raio inv�lido");
            }

            /* else if (raio <=0)
             {
                 MessageBox.Show("Raio deve ser maior que zero");
             }*/

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura)
                || (altura <= 0))
            {
                MessageBox.Show("Altura inv�lida");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio)
                || (raio <= 0))
            {
                MessageBox.Show("Raio inv�lido");
                txtRaio.Focus();
            }

            else if (!Double.TryParse(txtAltura.Text, out altura)
                || (altura <= 0))
            {
                MessageBox.Show("Altura inv�lida");
                txtAltura.Focus();
            }

            else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                txtVolume.Text = volume.ToString("N2");
            }
        }

        private void txtVolume_Validated(object sender, EventArgs e)
        {

        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            txtAltura.Text = String.Empty;
            txtVolume.Clear();
        }
    }
}
